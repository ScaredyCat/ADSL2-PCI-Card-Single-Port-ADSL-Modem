#!/usr/bin/perl
#
# Abspielen und L"oschen der ausgew"ahlten Anrufe
#
# Marc Neitzner Dez 96
##################################################
$| = 1;

# Systemspezifische Angaben
#
$vbox       = join("","/cgi-",$ENV{'REMOTE_USER'},"/vbox.pl");
$vboxremote = '/usr/local/bin/vboxremote';
$convert    = '/usr/local/bin/zyxel2au';
$rm         = '/bin/rm';
$tmpcall    = join ("","/tmp/",$ENV{'REMOTE_USER'},".au");
$webmaster  = "marc\@zeus\.han\.de";
$poorhost   = "climb.han.de";

# Filtern der Uebergabeparameter
#  
&parse_from_data (*parameter);
$todo = $parameter{'todo'};

# Rueckgewinnung des urspruenglichen Dateinamens
#
if (substr($parameter{'call'},-3) eq "(N)") {
   $call = substr($parameter{'call'},0,-4);
}
else {
   $call = $parameter{'call'};
}
$call    =~ s/ //g; $call   =~ s/\.//g; $call   =~ s/://g;
$day     = substr($call,0,2); 
$month   = substr($call,2,2);
$year    = substr($call,4,2);
$time    = substr($call,6,6);
$num     = substr($call,12);
$call    = join("",$year,$month,$day,$time,"-",$num);
$fcall   = join ("","/var/spool/vbox/",$ENV{'REMOTE_USER'},
                 "/incoming/", $call);

# Ausgabe bzw. Loeschen des Anrufes
#
if ($todo eq "Abh�ren") {
   system ($convert, $fcall, $tmpcall); 
   if ($ENV{'REMOTE_HOST'} eq $poorhost) {
	if (!-x $fcall) {
	   chmod(0700, $fcall);
	}
	exec($vboxremote, $tmpcall, $call, $ENV{'REMOTE_USER'});
   }
   else { 
      if (open (CALL, "<" . $tmpcall)) {
        $no_bytes = (stat ($tmpcall))[7];
        print "Content-type: audio/basic", "\n";
        print "Content-length: $no_bytes", "\n\n";
        print <CALL>;
        system($rm, $tmpcall);
	if (!-x $fcall) {
	   chmod(0700, $fcall);
	}
      }
      else {
        print "Content-type: text/plain", "\n\n";
        print "Unable to open $tmpcall !", "\n";
      }
   }
}
elsif ($todo eq "L�schen") {
  system ($rm, $fcall);
   print "Location: $vbox", "\n\n";
}
else {
  print "Content-type: text/plain", "\n\n";
  print "Don't know anything about $call !", "\n";
}
exit(0);

# Uebernahme und Aufdroeseln des QUERY_STRING
#
sub parse_from_data
{
  local (*FORM_DATA) = @_;
  local ($request_method, $query_string, @key_value_pairs,
         $key_value, $key, $value);

  $request_method = $ENV{'REQUEST_METHOD'};
  
  if ($request_method eq "GET") {
    $query_string = $ENV{'QUERY_STRING'};
  }
  elsif ($request_method eq "POST") {
    $| = 1;
    read (STDIN, $query_string, $ENV{'CONTENT_LENGTH'});
  }
  else {
    &return_error (500, "Server Error",
		        "Unknown Method $request_method");
  }   
  @key_value_pairs = split (/&/, $query_string);

  foreach $key_value (@key_value_pairs) {
       ($key, $value) = split (/=/, $key_value);
       $value =~ tr/+/ /;
       $value =~ s/%([\dA-Fa-f][\dA-Fa-f])/pack ("C", hex ($1))/eg;
       if (defined($FORM_DATA{$key})) {
          $FORM_DATA{$key} = join ("|", $FORM_DATA{$key}, $value);
       }
       else {
          $FORM_DATA{$key} = $value;
       }
   }
}

# Fehlerroutine
#
sub return_error
{
  local ($status, $keyword, $message) = @_;

  print "Content-type: text/html", "\n";
  print "Status: ", $status, " ", $keyword, "\n\n";
  
  print <<End_of_Error;
  <HTML>
  <HEAD>
  <TITLE>CGI-Program - unexpected error</TITLE>
  </HEAD>
  <BODY>
  <H1>$keyword</H1>
  <HR>
  $message
  <HR>
  Contact <A HREF="mailto:$webmaster"> $webmaster</A> for further
  information.
  </BODY>
  </HTML>

End_of_Error
  exit(1);
}
