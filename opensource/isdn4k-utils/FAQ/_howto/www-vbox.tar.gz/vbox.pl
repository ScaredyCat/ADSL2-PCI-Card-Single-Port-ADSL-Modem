#!/usr/bin/perl
#
# Abfrage des i4l-Anrufbeantwoters mittels eines Web-Browser.
#
# Notwendig hierzu ist die Ausf"urung des Skriptes mit den
# entsprechenden User-Rechten ! Neuere HTTP-Server wie der
# apache-1.2b* unterstuetzen diese M"oglichkeit.
#
# Marc Neitzner Dez 96
###############################################################

# Systemspezifische Angaben 
#
$vbox_path = "/var/spool/vbox";
$vboxplay  = join("","/cgi-",$ENV{'REMOTE_USER'},"/vboxplay.pl");
#

$ruser     = $ENV{'REMOTE_USER'};
$ruser     =~ tr/a-z/A-Z/;

# Erstellen der Anrufbeantworter-Seite
#
print <<EOM;
Content-type: text/html

<HTML>
<HEAD>
<TITLE>Anrufbeantworter</TITLE>
</HEAD>

<BODY>
	<IMG ALIGN=CENTER SRC="/icons/phone.gif">
	<FONT SIZE=6>
        ${ruser}s Anrufbeantworter
	</FONT>
	<HR>
	<FORM ACTION="$vboxplay" METHOD="GET">
	Eingegangene Anrufe:<BR>
        <I><PRE>Datum  Zeit  Rufnummer</PRE></I>
	<SELECT NAME="call" SIZE=5 MULTIPLE>
EOM
	&ListCalls;
print <<EOM;
	</SELECT>
	<HR>
	<INPUT TYPE="submit" NAME="todo" VALUE="Abh&ouml;ren">
	<INPUT TYPE="submit" NAME="todo" VALUE="L&ouml;schen">
	</FORM>
</BODY>
</HTML>
EOM

sub ListCalls 
{
   $user_path = join ("","/var/spool/vbox/",$ENV{'REMOTE_USER'},"/incoming");
   @directory = split (/\n/, `ls -1 $user_path`);
   foreach $file (@directory) {
	$year  = substr($file,0,2);
	$month = substr($file,2,2);
	$day   = substr($file,4,2);
	$hour  = substr($file,6,2);
	$min   = substr($file,8,2);
	$sec   = substr($file,10,2);
	$num   = substr($file,13);
	$ffile = join("",$user_path,"/",$file);
	if (-x $ffile) {
	   print ("	<OPTION>$day.$month.$year     $hour:$min:$sec     $num$neu\n");
        }
        else {
	   print ("	<OPTION>$day.$month.$year     $hour:$min:$sec     $num$neu (N)\n");
        }
   }
}
