#!/bin/sh
TOPDIR=`pwd`/../../../../
. ${TOPDIR}tools/build_tools/Path.sh
APPS_NAME="isdn4k-utils"

echo "----------------------------------------------------------------------"
echo "-----------------------       build isdn4k-utils      ----------------"
echo "----------------------------------------------------------------------"

parse_args $@

if [ $BUILD_CLEAN -eq 1 ]; then
	make clean
fi

if [ "$1" = "config_only" ] ; then
	aclocal
	autoheader
	autoconf
	automake --foreign --add-missing
	AR=${IFX_AR} AS=${IFX_AS} LD=${IFX_LD} NM=${IFX_NM} CC=${IFX_CC}  RANLIB=${IFX_RANLIB} BUILDCC=${IFX_HOSTCC} CXX=${IFX_CXX} OBJCOPY=${IFX_OBJCOPY} OBJDUMP=${IFX_OBJDUMP} IFX_CFLAGS={IFX_CFLAGS} IFX_LDFLAGS={IFX_LDFLAGS}
    exit $?
fi

make AR=${IFX_AR} AS=${IFX_AS} LD=${IFX_LD} NM=${IFX_NM} CC=${IFX_CC} BUILDCC=${IFX_HOSTCC} GCC=${IFX_CC} CXX=${IFX_CXX} CPP=${IFX_CPP} RANLIB=${IFX_RANLIB} IFX_CFLAGS="${IFX_CFLAGS}" IFX_LDFLAGS="${IFX_LDFLAGS}" KERNEL_DIR=${KERNEL_SOURCE_DIR} install
ifx_error_check $? 


#${IFX_STRIP} noip2
#cp -af ./noip2 ${BUILD_ROOTFS_DIR}usr/sbin/noip2
#chmod 700 ${BUILD_ROOTFS_DIR}usr/sbin/noip2
#chown root:root ${BUILD_ROOTFS_DIR}usr/sbin/noip2
#ifx_error_check $? 
