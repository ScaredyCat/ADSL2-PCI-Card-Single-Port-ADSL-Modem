#define	PATCHLEVEL	12

#define VERSION		"i2.2"
#define IMPLEMENTATION	""
#define DATE		"Jan 10, 2000"
