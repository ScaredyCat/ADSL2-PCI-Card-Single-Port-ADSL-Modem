/* $Id: patchlevel.h,v 1.2 2001/05/03 09:00:51 calle Exp $ */
#define	PATCHLEVEL	11

#define VERSION		"2.3"
#define IMPLEMENTATION	""
#define DATE		"23 December 1999"
