/*
** $Id: rcgetty.h,v 1.3 1997/02/26 13:10:47 michael Exp $
**
** Copyright (C) 1996, 1997 Michael 'Ghandi' Herold
*/

#ifndef _VBOX_RCGETTY_H
#define _VBOX_RCGETTY_H 1

/** Prototypes ***********************************************************/

extern int getty_get_settings(char *);

#endif /* _VBOX_RCGETTY_H */
