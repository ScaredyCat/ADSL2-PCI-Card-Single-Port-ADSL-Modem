
extern int tdu_sbv_connect(int);
extern int tdu_sbv_disconnect(int);
extern int tdu_sbv_accept(int);
