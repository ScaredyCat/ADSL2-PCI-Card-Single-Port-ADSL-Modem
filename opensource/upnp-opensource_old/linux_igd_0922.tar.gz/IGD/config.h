#ifndef _CONFIG_H_
	#define _CONFIG_H_

char extInterfaceName[10];
char intInterfaceName[10];
char intIpAddress[16];

#endif // _CONFIG_H_
