#ifndef _UTIL_H_
	#define _UTIL_H_

int get_sockfd();
int GetIpAddressStr(char *address, char *ifname);

#endif //_UTIL_H_
